from django.contrib import admin

# Register your models here.
from test_app.models import UnionBoard 
admin.site.register(UnionBoard)